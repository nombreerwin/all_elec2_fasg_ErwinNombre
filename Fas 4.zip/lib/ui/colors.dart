import 'dart:ui';

const Color green = Color(0xffffffff);
const Color lightGrey = Color(0xffffffff);
const Color shim = Color(0x7f000000);
